declare module 'svelte/package.json';
declare module 'coffeescript';
declare module 'strip-indent';
declare module 'postcss-load-config';
declare module 'less';
