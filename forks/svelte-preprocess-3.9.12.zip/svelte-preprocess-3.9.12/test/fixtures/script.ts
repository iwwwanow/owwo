export var hello: string = 'world';
