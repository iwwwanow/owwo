export type AType = "test1" | "test2"
export interface AInterface {
    test: string
}
export const AValue: string = "test"

export default "String"