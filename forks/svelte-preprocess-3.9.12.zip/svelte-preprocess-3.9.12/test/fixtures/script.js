export var hello = 'world';
