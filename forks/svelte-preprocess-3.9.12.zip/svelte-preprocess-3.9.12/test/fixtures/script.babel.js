export var hello = {};
export var world = hello?.value;
