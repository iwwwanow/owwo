module.exports = {
  plugins: [
    require('autoprefixer')({
      overrideBrowserslist: 'Safari >= 5.1',
    }),
  ],
}
