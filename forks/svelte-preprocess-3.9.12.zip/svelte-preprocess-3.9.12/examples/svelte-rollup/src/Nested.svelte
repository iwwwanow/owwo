<script>
  export let label = ''
</script>

<div> Your name is '{label}' </div>
