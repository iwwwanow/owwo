<template lang="pug">
  svelte:head
    title About

  h1 About this site

  p This is the 'about' page. There's not much here.
</template>