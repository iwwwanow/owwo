---
question: Are there any third-party resources?
---

Svelte Society maintains a [list of books and videos](https://sveltesociety.dev/resources).
