---
question: How can I get VS Code to syntax-highlight my .svelte files?
---

There is an [official VS Code extension for Svelte](https://marketplace.visualstudio.com/items?itemName=svelte.svelte-vscode).
