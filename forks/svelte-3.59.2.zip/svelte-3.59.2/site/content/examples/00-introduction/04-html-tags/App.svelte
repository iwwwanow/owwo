<script>
	let string = `here's some <strong>HTML!!!</strong>`;
</script>

<p>{@html string}</p>