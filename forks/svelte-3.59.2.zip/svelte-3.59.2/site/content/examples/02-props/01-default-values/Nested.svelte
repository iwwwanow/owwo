<script>
	export let answer = 'a mystery';
</script>

<p>The answer is {answer}</p>