<strong>Red thing</strong>

<style>
	strong {
		color: red;
	}
</style>