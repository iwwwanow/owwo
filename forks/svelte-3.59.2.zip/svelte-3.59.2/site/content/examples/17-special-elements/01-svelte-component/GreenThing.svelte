<strong>Green thing</strong>

<style>
	strong {
		color: green;
	}
</style>