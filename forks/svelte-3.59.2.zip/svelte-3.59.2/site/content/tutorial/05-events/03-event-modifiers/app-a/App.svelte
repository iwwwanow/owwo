<script>
	function handleClick() {
		alert('clicked')
	}
</script>

<button on:click={handleClick}>
	Click me
</button>