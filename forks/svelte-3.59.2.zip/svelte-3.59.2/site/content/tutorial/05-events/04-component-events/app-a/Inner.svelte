<script>
	// setup code goes here

	function sayHello() {

	}
</script>

<button on:click={sayHello}>
	Click to say hello
</button>