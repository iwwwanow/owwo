<script>
	import { count } from './stores.js';

	function decrement() {
		// TODO decrement the count
	}
</script>

<button on:click={decrement}>
	-
</button>